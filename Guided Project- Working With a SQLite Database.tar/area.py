import sqlite3
import pandas as pd
area_land_query='SELECT SUM(area_land) FROM facts WHERE area_land!="";'
area_water_query='SELECT SUM(area_water) FROM facts WHERE area_water!="";'
conn=sqlite3.connect('factbook.db')
data_area_land=pd.read_sql_query(area_land_query,conn)
data_area_water=pd.read_sql_query(area_water_query,conn)

print(data_area_land['SUM(area_land)'][0]/data_area_water['SUM(area_water)'][0]) 