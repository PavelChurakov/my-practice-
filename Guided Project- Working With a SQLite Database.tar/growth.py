import sqlite3
import pandas as pd
import math

conn=sqlite3.connect('factbook.db')
query='SELECT * FROM facts;'
data=pd.read_sql_query(query,conn)
data=data.dropna()
data=data[data['area_land']!=0]

def population_2050(row,t=35):
    population_t=int(row['population']*math.e**(row['population_growth']*t/100))
    return population_t 

data['population_in2050']=data.apply(population_2050,axis=1)                 
result_data=data.sort_values('population_in2050',ascending=False)    
data_lose_population =data[(data['population_in2050']-data['population'])<0]

data['population_densities']=data.apply(lambda row: row['population']/row['area_land'],axis=1)
data_highest_population=data.sort_values('population_densities',ascending=False)


print(result_data[['name','population','population_growth','population_in2050']].head(10))
print(data_lose_population)   
print(data[data['name']=='Ukraine'])
print(data_highest_population[['name','population','area_land']].head(10))  