import sqlite3 
conn=sqlite3.connect('factbook.db')
cursor=conn.cursor()
query='SELECT * FROM facts ORDER BY population ASC LIMIT 10;'
cursor.execute(query)
print(cursor.fetchall())